import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-37272a9d/health", (c) => {
  return c.json({ status: "ok" });
});

// Admin login
app.post("/make-server-37272a9d/admin/login", async (c) => {
  try {
    const { password } = await c.req.json();
    
    // Get stored admin password (default: admin123)
    let storedPassword = await kv.get("admin_password");
    if (!storedPassword) {
      await kv.set("admin_password", "admin123");
      storedPassword = "admin123";
    }
    
    if (password === storedPassword) {
      return c.json({ success: true, message: "Login successful" });
    } else {
      return c.json({ success: false, message: "Invalid password" }, 401);
    }
  } catch (error) {
    console.log(`Admin login error: ${error}`);
    return c.json({ success: false, message: `Login error: ${error}` }, 500);
  }
});

// Create test (admin only)
app.post("/make-server-37272a9d/tests/create", async (c) => {
  try {
    const { grade, month, questions } = await c.req.json();
    
    if (!grade || !month || !questions) {
      return c.json({ success: false, message: "Missing required fields" }, 400);
    }
    
    if (questions.length > 30) {
      return c.json({ success: false, message: "Maximum 30 questions allowed" }, 400);
    }
    
    const testKey = `test_${grade}_${month}`;
    await kv.set(testKey, JSON.stringify({
      grade,
      month,
      questions,
      createdAt: new Date().toISOString()
    }));
    
    return c.json({ success: true, message: "Test created successfully" });
  } catch (error) {
    console.log(`Test creation error: ${error}`);
    return c.json({ success: false, message: `Test creation error: ${error}` }, 500);
  }
});

// Get tests by grade
app.get("/make-server-37272a9d/tests/:grade/:month", async (c) => {
  try {
    const grade = c.req.param("grade");
    const month = c.req.param("month");
    
    const testKey = `test_${grade}_${month}`;
    const testData = await kv.get(testKey);
    
    if (!testData) {
      return c.json({ success: false, message: "Test not found" }, 404);
    }
    
    const test = JSON.parse(testData);
    
    // Remove correct answers from questions
    const questionsWithoutAnswers = test.questions.map((q: any) => ({
      question: q.question,
      options: q.options
    }));
    
    return c.json({ 
      success: true, 
      test: {
        grade: test.grade,
        month: test.month,
        questions: questionsWithoutAnswers
      }
    });
  } catch (error) {
    console.log(`Get test error: ${error}`);
    return c.json({ success: false, message: `Get test error: ${error}` }, 500);
  }
});

// Check if student already submitted
app.post("/make-server-37272a9d/submissions/check", async (c) => {
  try {
    const { firstName, lastName, grade, month } = await c.req.json();
    
    const studentId = `${firstName}_${lastName}_${grade}_${month}`.toLowerCase().replace(/\s+/g, '_');
    const submissionKey = `submission_${studentId}`;
    
    const submission = await kv.get(submissionKey);
    
    if (submission) {
      const submissionData = JSON.parse(submission);
      return c.json({ 
        success: true, 
        hasSubmitted: true,
        submission: submissionData
      });
    }
    
    return c.json({ success: true, hasSubmitted: false });
  } catch (error) {
    console.log(`Check submission error: ${error}`);
    return c.json({ success: false, message: `Check submission error: ${error}` }, 500);
  }
});

// Submit test
app.post("/make-server-37272a9d/submissions/submit", async (c) => {
  try {
    const { firstName, lastName, grade, month, answers, timeSpent } = await c.req.json();
    
    if (!firstName || !lastName || !grade || !month || !answers) {
      return c.json({ success: false, message: "Missing required fields" }, 400);
    }
    
    // Check if already submitted
    const studentId = `${firstName}_${lastName}_${grade}_${month}`.toLowerCase().replace(/\s+/g, '_');
    const submissionKey = `submission_${studentId}`;
    const existingSubmission = await kv.get(submissionKey);
    
    if (existingSubmission) {
      return c.json({ success: false, message: "Test already submitted" }, 400);
    }
    
    // Get test to calculate score
    const testKey = `test_${grade}_${month}`;
    const testData = await kv.get(testKey);
    
    if (!testData) {
      return c.json({ success: false, message: "Test not found" }, 404);
    }
    
    const test = JSON.parse(testData);
    let score = 0;
    
    // Calculate score
    test.questions.forEach((q: any, index: number) => {
      if (answers[index] === q.correctAnswer) {
        score++;
      }
    });
    
    const totalQuestions = test.questions.length;
    const percentage = (score / totalQuestions) * 100;
    
    // Save submission
    const submission = {
      firstName,
      lastName,
      grade,
      month,
      answers,
      score,
      totalQuestions,
      percentage: percentage.toFixed(2),
      timeSpent,
      submittedAt: new Date().toISOString()
    };
    
    await kv.set(submissionKey, JSON.stringify(submission));
    
    return c.json({ 
      success: true, 
      message: "Test submitted successfully",
      score,
      totalQuestions,
      percentage: percentage.toFixed(2)
    });
  } catch (error) {
    console.log(`Submit test error: ${error}`);
    return c.json({ success: false, message: `Submit test error: ${error}` }, 500);
  }
});

// Get all results (admin only)
app.get("/make-server-37272a9d/admin/results/:month", async (c) => {
  try {
    const month = c.req.param("month");
    
    // Get all submissions with prefix
    const allSubmissions = await kv.getByPrefix(`submission_`);
    
    if (!allSubmissions || allSubmissions.length === 0) {
      return c.json({ success: true, results: [], totalStudents: 0 });
    }
    
    // Parse and filter by month
    const results = allSubmissions
      .map((s: string) => JSON.parse(s))
      .filter((s: any) => s.month === month)
      .sort((a: any, b: any) => b.score - a.score);
    
    // Add rank
    results.forEach((result: any, index: number) => {
      result.rank = index + 1;
    });
    
    return c.json({ 
      success: true, 
      results,
      totalStudents: results.length
    });
  } catch (error) {
    console.log(`Get results error: ${error}`);
    return c.json({ success: false, message: `Get results error: ${error}` }, 500);
  }
});

// Get available tests list
app.get("/make-server-37272a9d/tests/list", async (c) => {
  try {
    const allTests = await kv.getByPrefix("test_");
    
    if (!allTests || allTests.length === 0) {
      return c.json({ success: true, tests: [] });
    }
    
    const tests = allTests.map((t: string) => {
      const test = JSON.parse(t);
      return {
        grade: test.grade,
        month: test.month,
        questionCount: test.questions.length,
        createdAt: test.createdAt
      };
    });
    
    return c.json({ success: true, tests });
  } catch (error) {
    console.log(`Get tests list error: ${error}`);
    return c.json({ success: false, message: `Get tests list error: ${error}` }, 500);
  }
});

Deno.serve(app.fetch);