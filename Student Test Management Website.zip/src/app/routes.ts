import { createBrowserRouter } from "react-router";
import App from "./App";
import LoginPage from "./components/LoginPage";
import AdminDashboard from "./components/AdminDashboard";
import TestCreator from "./components/TestCreator";
import StudentTest from "./components/StudentTest";
import TestResults from "./components/TestResults";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [
      { index: true, element: <LoginPage /> },
      { path: "admin", element: <AdminDashboard /> },
      { path: "admin/create-test", element: <TestCreator /> },
      { path: "student/test", element: <StudentTest /> },
      { path: "student/results", element: <TestResults /> },
      { path: "*", element: <LoginPage /> },
    ],
  },
]);