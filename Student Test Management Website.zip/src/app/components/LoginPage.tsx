import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { toast } from 'sonner';
import { GraduationCap, Shield } from 'lucide-react';
import { projectId, publicAnonKey } from '/utils/supabase/info';

export default function LoginPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<'select' | 'admin' | 'student'>('select');
  const [adminPassword, setAdminPassword] = useState('');
  const [studentInfo, setStudentInfo] = useState({
    firstName: '',
    lastName: '',
    grade: ''
  });
  const [loading, setLoading] = useState(false);

  const handleAdminLogin = async () => {
    if (!adminPassword.trim()) {
      toast.error('Please enter admin password');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-37272a9d/admin/login`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`
          },
          body: JSON.stringify({ password: adminPassword })
        }
      );

      const data = await response.json();

      if (data.success) {
        toast.success('Login successful');
        localStorage.setItem('isAdmin', 'true');
        navigate('/admin');
      } else {
        toast.error(data.message || 'Invalid password');
      }
    } catch (error) {
      console.error('Admin login error:', error);
      toast.error('Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleStudentLogin = () => {
    const { firstName, lastName, grade } = studentInfo;

    if (!firstName.trim() || !lastName.trim() || !grade.trim()) {
      toast.error('Please fill in all fields');
      return;
    }

    // Store student info in localStorage
    localStorage.setItem('studentInfo', JSON.stringify(studentInfo));
    navigate('/student/test');
  };

  if (mode === 'select') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <Card className="w-full max-w-md shadow-xl">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold text-gray-800">
              BBS Monthly Test Platform
            </CardTitle>
            <CardDescription className="text-lg mt-2">
              Select your login type to continue
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 pt-4">
            <Button 
              className="w-full h-16 text-lg font-semibold bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 transition-all"
              onClick={() => setMode('admin')}
            >
              <Shield className="mr-2 size-6" />
              Admin Login
            </Button>
            <Button 
              className="w-full h-16 text-lg font-semibold bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 transition-all"
              onClick={() => setMode('student')}
            >
              <GraduationCap className="mr-2 size-6" />
              Student Login
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (mode === 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <Card className="w-full max-w-md shadow-xl">
          <CardHeader>
            <Button 
              variant="ghost" 
              onClick={() => setMode('select')}
              className="w-fit mb-2"
            >
              ← Back
            </Button>
            <CardTitle className="text-2xl font-bold text-center">
              Admin Login
            </CardTitle>
            <CardDescription className="text-center">
              Enter admin password to access dashboard
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter admin password"
                value={adminPassword}
                onChange={(e) => setAdminPassword(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAdminLogin()}
              />
              <p className="text-xs text-gray-500">Default password: admin123</p>
            </div>
            <Button 
              className="w-full" 
              onClick={handleAdminLogin}
              disabled={loading}
            >
              {loading ? 'Logging in...' : 'Login'}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-emerald-100 p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader>
          <Button 
            variant="ghost" 
            onClick={() => setMode('select')}
            className="w-fit mb-2"
          >
            ← Back
          </Button>
          <CardTitle className="text-2xl font-bold text-center">
            Student Login
          </CardTitle>
          <CardDescription className="text-center">
            Enter your information to start the test
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="firstName">First Name</Label>
            <Input
              id="firstName"
              placeholder="Enter your first name"
              value={studentInfo.firstName}
              onChange={(e) => setStudentInfo({ ...studentInfo, firstName: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="lastName">Last Name</Label>
            <Input
              id="lastName"
              placeholder="Enter your last name"
              value={studentInfo.lastName}
              onChange={(e) => setStudentInfo({ ...studentInfo, lastName: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="grade">Grade</Label>
            <Input
              id="grade"
              placeholder="Enter your grade (e.g., 9, 10, 11)"
              value={studentInfo.grade}
              onChange={(e) => setStudentInfo({ ...studentInfo, grade: e.target.value })}
            />
          </div>
          <Button 
            className="w-full" 
            onClick={handleStudentLogin}
          >
            Start Test
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
