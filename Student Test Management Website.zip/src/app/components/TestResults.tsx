import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Trophy, Clock, CheckCircle2, Home } from 'lucide-react';

export default function TestResults() {
  const navigate = useNavigate();
  const [results, setResults] = useState<any>(null);

  useEffect(() => {
    const stored = localStorage.getItem('testResults');
    if (!stored) {
      navigate('/');
      return;
    }
    setResults(JSON.parse(stored));
  }, [navigate]);

  const handleGoHome = () => {
    localStorage.removeItem('studentInfo');
    localStorage.removeItem('testResults');
    navigate('/');
  };

  if (!results) {
    return null;
  }

  const percentage = parseFloat(results.percentage);
  const passed = percentage >= 60;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 p-4 flex items-center justify-center">
      <div className="max-w-2xl w-full">
        {/* Celebration Card */}
        <Card className="mb-6 border-4 border-gradient shadow-2xl">
          <CardHeader className="text-center pb-4">
            <div className="flex justify-center mb-4">
              {passed ? (
                <div className="w-24 h-24 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center animate-bounce">
                  <Trophy className="size-12 text-white" />
                </div>
              ) : (
                <div className="w-24 h-24 bg-gradient-to-br from-amber-400 to-amber-600 rounded-full flex items-center justify-center">
                  <CheckCircle2 className="size-12 text-white" />
                </div>
              )}
            </div>
            <CardTitle className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              {passed ? 'Congratulations!' : 'Test Completed!'}
            </CardTitle>
            <CardDescription className="text-xl mt-2">
              {results.firstName} {results.lastName}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Score Display */}
            <div className="bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl p-8 text-white text-center">
              <p className="text-sm uppercase tracking-wide opacity-90 mb-2">Your Score</p>
              <div className="text-7xl font-bold mb-2">
                {results.score}/{results.totalQuestions}
              </div>
              <div className="text-4xl font-bold">
                {results.percentage}%
              </div>
              {passed ? (
                <p className="mt-4 text-lg bg-white/20 rounded-full px-6 py-2 inline-block">
                  ✨ Excellent Work! ✨
                </p>
              ) : (
                <p className="mt-4 text-lg bg-white/20 rounded-full px-6 py-2 inline-block">
                  Keep practicing!
                </p>
              )}
            </div>

            {/* Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="bg-gradient-to-br from-indigo-50 to-indigo-100 border-indigo-200">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-indigo-600 rounded-lg flex items-center justify-center">
                      <Clock className="size-6 text-white" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Time Spent</p>
                      <p className="text-2xl font-bold text-gray-800">
                        {Math.floor(results.timeSpent / 60)} min
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center">
                      <CheckCircle2 className="size-6 text-white" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Grade</p>
                      <p className="text-2xl font-bold text-gray-800">
                        {results.grade}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Performance Feedback */}
            <Card className={`border-2 ${
              percentage >= 90 ? 'bg-green-50 border-green-500' :
              percentage >= 75 ? 'bg-blue-50 border-blue-500' :
              percentage >= 60 ? 'bg-yellow-50 border-yellow-500' :
              'bg-orange-50 border-orange-500'
            }`}>
              <CardContent className="pt-6">
                <h3 className="font-bold text-lg mb-2">Performance Analysis</h3>
                <p className="text-gray-700">
                  {percentage >= 90 && "Outstanding performance! You've mastered this material excellently. Keep up the fantastic work!"}
                  {percentage >= 75 && percentage < 90 && "Great job! You have a strong understanding of the material. A little more practice and you'll be at the top!"}
                  {percentage >= 60 && percentage < 75 && "Good effort! You've passed the test. Focus on reviewing the topics you found challenging to improve further."}
                  {percentage < 60 && "You've completed the test! Consider reviewing the material and practicing more. Don't give up – improvement comes with practice!"}
                </p>
              </CardContent>
            </Card>

            {/* Important Notice */}
            <div className="bg-amber-50 border-2 border-amber-300 rounded-lg p-4">
              <p className="text-center text-amber-800 font-semibold">
                ⚠️ Note: You cannot retake this test. Your results have been saved.
              </p>
            </div>

            {/* Action Button */}
            <Button
              onClick={handleGoHome}
              size="lg"
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            >
              <Home className="mr-2 size-5" />
              Return to Home
            </Button>
          </CardContent>
        </Card>

        {/* Footer Message */}
        <p className="text-center text-gray-600">
          Your results have been submitted to the administrator.
        </p>
      </div>
    </div>
  );
}
