import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Progress } from './ui/progress';
import { toast } from 'sonner';
import { Clock, AlertCircle, Send } from 'lucide-react';
import { projectId, publicAnonKey } from '/utils/supabase/info';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "./ui/alert-dialog";

interface Question {
  question: string;
  options: string[];
}

const TEST_DURATION = 2 * 60 * 60 * 1000; // 2 hours in milliseconds

export default function StudentTest() {
  const navigate = useNavigate();
  const [studentInfo, setStudentInfo] = useState<any>(null);
  const [month, setMonth] = useState('');
  const [testLoaded, setTestLoaded] = useState(false);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [answers, setAnswers] = useState<number[]>([]);
  const [timeRemaining, setTimeRemaining] = useState(TEST_DURATION);
  const [startTime, setStartTime] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [showSubmitDialog, setShowSubmitDialog] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem('studentInfo');
    if (!stored) {
      navigate('/');
      return;
    }
    setStudentInfo(JSON.parse(stored));
  }, [navigate]);

  useEffect(() => {
    if (!testLoaded || !startTime) return;

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const remaining = Math.max(0, TEST_DURATION - elapsed);
      setTimeRemaining(remaining);

      if (remaining === 0) {
        handleAutoSubmit();
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [testLoaded, startTime]);

  const loadTest = async () => {
    if (!month.trim()) {
      toast.error('Please enter the test month');
      return;
    }

    if (!studentInfo) return;

    setLoading(true);
    try {
      // Check if already submitted
      const checkResponse = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-37272a9d/submissions/check`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`
          },
          body: JSON.stringify({
            firstName: studentInfo.firstName,
            lastName: studentInfo.lastName,
            grade: studentInfo.grade,
            month
          })
        }
      );

      const checkData = await checkResponse.json();

      if (checkData.hasSubmitted) {
        toast.error('You have already completed this test!');
        localStorage.setItem('testResults', JSON.stringify(checkData.submission));
        navigate('/student/results');
        return;
      }

      // Load test
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-37272a9d/tests/${studentInfo.grade}/${month}`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );

      const data = await response.json();

      if (data.success) {
        setQuestions(data.test.questions);
        setAnswers(new Array(data.test.questions.length).fill(-1));
        setTestLoaded(true);
        setStartTime(Date.now());
        toast.success('Test loaded! Timer started.');
      } else {
        toast.error(data.message || 'Test not found for your grade');
      }
    } catch (error) {
      console.error('Load test error:', error);
      toast.error('Failed to load test. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleAutoSubmit = async () => {
    toast.error('Time is up! Submitting your test...');
    await submitTest();
  };

  const submitTest = async () => {
    if (!studentInfo || !startTime) return;

    // Check if all questions are answered
    const unanswered = answers.filter(a => a === -1).length;
    if (unanswered > 0) {
      toast.warning(`${unanswered} question(s) left unanswered`);
    }

    const timeSpent = Math.floor((Date.now() - startTime) / 1000); // in seconds

    setLoading(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-37272a9d/submissions/submit`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`
          },
          body: JSON.stringify({
            firstName: studentInfo.firstName,
            lastName: studentInfo.lastName,
            grade: studentInfo.grade,
            month,
            answers,
            timeSpent
          })
        }
      );

      const data = await response.json();

      if (data.success) {
        toast.success('Test submitted successfully!');
        localStorage.setItem('testResults', JSON.stringify({
          ...studentInfo,
          score: data.score,
          totalQuestions: data.totalQuestions,
          percentage: data.percentage,
          timeSpent
        }));
        navigate('/student/results');
      } else {
        toast.error(data.message || 'Failed to submit test');
      }
    } catch (error) {
      console.error('Submit test error:', error);
      toast.error('Failed to submit test. Please try again.');
    } finally {
      setLoading(false);
      setShowSubmitDialog(false);
    }
  };

  const formatTime = (ms: number) => {
    const totalSeconds = Math.floor(ms / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  const answeredCount = answers.filter(a => a !== -1).length;
  const progress = questions.length > 0 ? (answeredCount / questions.length) * 100 : 0;

  if (!testLoaded) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 p-4 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Start Your Test</CardTitle>
            <CardDescription>
              Welcome, {studentInfo?.firstName} {studentInfo?.lastName}!<br />
              Grade: {studentInfo?.grade}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="month">Enter Test Month</Label>
              <Input
                id="month"
                placeholder="e.g., February2026"
                value={month}
                onChange={(e) => setMonth(e.target.value)}
              />
            </div>
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 space-y-2">
              <div className="flex items-start gap-2">
                <AlertCircle className="size-5 text-amber-600 mt-0.5" />
                <div className="text-sm text-amber-800">
                  <p className="font-semibold mb-1">Important Instructions:</p>
                  <ul className="list-disc list-inside space-y-1">
                    <li>You have 2 hours to complete the test</li>
                    <li>The timer starts immediately when you load the test</li>
                    <li>You cannot retake the test once submitted</li>
                    <li>Make sure you have a stable internet connection</li>
                  </ul>
                </div>
              </div>
            </div>
            <Button
              className="w-full"
              onClick={loadTest}
              disabled={loading}
            >
              {loading ? 'Loading Test...' : 'Load Test & Start Timer'}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Timer Bar */}
        <Card className="mb-6 sticky top-4 z-10 shadow-lg">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Clock className="size-5 text-blue-600" />
                <span className="font-semibold">Time Remaining:</span>
                <span className={`text-2xl font-mono font-bold ${
                  timeRemaining < 600000 ? 'text-red-600 animate-pulse' : 'text-green-600'
                }`}>
                  {formatTime(timeRemaining)}
                </span>
              </div>
              <div className="text-sm text-gray-600">
                Progress: {answeredCount}/{questions.length} answered
              </div>
            </div>
            <Progress value={progress} className="h-2" />
          </CardContent>
        </Card>

        {/* Questions */}
        <div className="space-y-6 mb-6">
          {questions.map((question, qIndex) => (
            <Card key={qIndex} className={`transition-all ${
              answers[qIndex] !== -1 ? 'border-green-500 border-2' : 'border-gray-200'
            }`}>
              <CardHeader>
                <CardTitle className="text-lg flex items-start gap-2">
                  <span className="flex items-center justify-center w-8 h-8 bg-blue-600 text-white rounded-full text-sm font-bold flex-shrink-0">
                    {qIndex + 1}
                  </span>
                  <span className="flex-1">{question.question}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <RadioGroup
                  value={answers[qIndex]?.toString()}
                  onValueChange={(value) => {
                    const updated = [...answers];
                    updated[qIndex] = parseInt(value);
                    setAnswers(updated);
                  }}
                >
                  <div className="space-y-3">
                    {question.options.map((option, oIndex) => (
                      <div
                        key={oIndex}
                        className={`flex items-start space-x-3 p-3 rounded-lg border-2 transition-all cursor-pointer ${
                          answers[qIndex] === oIndex
                            ? 'border-blue-500 bg-blue-50'
                            : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                        }`}
                        onClick={() => {
                          const updated = [...answers];
                          updated[qIndex] = oIndex;
                          setAnswers(updated);
                        }}
                      >
                        <RadioGroupItem value={oIndex.toString()} id={`q${qIndex}-o${oIndex}`} />
                        <Label
                          htmlFor={`q${qIndex}-o${oIndex}`}
                          className="flex-1 cursor-pointer font-normal"
                        >
                          <span className="font-semibold mr-2">{String.fromCharCode(65 + oIndex)}.</span>
                          {option}
                        </Label>
                      </div>
                    ))}
                  </div>
                </RadioGroup>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Submit Button */}
        <Card className="sticky bottom-4 shadow-lg">
          <CardContent className="pt-6">
            <Button
              onClick={() => setShowSubmitDialog(true)}
              disabled={loading}
              size="lg"
              className="w-full bg-green-600 hover:bg-green-700 text-lg"
            >
              <Send className="mr-2 size-5" />
              Submit Test
            </Button>
            {answeredCount < questions.length && (
              <p className="text-center text-sm text-amber-600 mt-2">
                ⚠️ Warning: {questions.length - answeredCount} question(s) not answered
              </p>
            )}
          </CardContent>
        </Card>

        {/* Submit Confirmation Dialog */}
        <AlertDialog open={showSubmitDialog} onOpenChange={setShowSubmitDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Submit Test?</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to submit your test? You cannot change your answers after submission.
                <br /><br />
                <strong>Answered: {answeredCount}/{questions.length} questions</strong>
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={submitTest} disabled={loading}>
                {loading ? 'Submitting...' : 'Submit Test'}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}
