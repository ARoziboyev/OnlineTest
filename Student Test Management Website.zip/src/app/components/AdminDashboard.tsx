import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { toast } from 'sonner';
import { Download, LogOut, Plus, Users, Trophy } from 'lucide-react';
import { projectId, publicAnonKey } from '/utils/supabase/info';
import * as XLSX from 'xlsx';

interface Result {
  firstName: string;
  lastName: string;
  grade: string;
  score: number;
  totalQuestions: number;
  percentage: string;
  timeSpent: number;
  submittedAt: string;
  rank: number;
}

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [results, setResults] = useState<Result[]>([]);
  const [totalStudents, setTotalStudents] = useState(0);
  const [selectedMonth, setSelectedMonth] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const isAdmin = localStorage.getItem('isAdmin');
    if (!isAdmin) {
      navigate('/');
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('isAdmin');
    navigate('/');
  };

  const fetchResults = async () => {
    if (!selectedMonth.trim()) {
      toast.error('Please enter a month');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-37272a9d/admin/results/${selectedMonth}`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`
          }
        }
      );

      const data = await response.json();

      if (data.success) {
        setResults(data.results);
        setTotalStudents(data.totalStudents);
        toast.success(`Loaded ${data.totalStudents} student results`);
      } else {
        toast.error(data.message || 'Failed to fetch results');
      }
    } catch (error) {
      console.error('Fetch results error:', error);
      toast.error('Failed to fetch results');
    } finally {
      setLoading(false);
    }
  };

  const exportToExcel = () => {
    if (results.length === 0) {
      toast.error('No results to export');
      return;
    }

    const exportData = results.map(result => ({
      'Rank': result.rank,
      'First Name': result.firstName,
      'Last Name': result.lastName,
      'Grade': result.grade,
      'Score': result.score,
      'Total Questions': result.totalQuestions,
      'Percentage': `${result.percentage}%`,
      'Time Spent (minutes)': Math.floor(result.timeSpent / 60),
      'Submitted At': new Date(result.submittedAt).toLocaleString()
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Results');

    // Auto-size columns
    const maxWidth = exportData.reduce((w, r) => Math.max(w, r['First Name'].length, r['Last Name'].length), 10);
    ws['!cols'] = [
      { wch: 6 },
      { wch: maxWidth },
      { wch: maxWidth },
      { wch: 8 },
      { wch: 8 },
      { wch: 16 },
      { wch: 12 },
      { wch: 20 },
      { wch: 20 }
    ];

    XLSX.writeFile(wb, `BBS_Test_Results_${selectedMonth}_${new Date().toISOString().split('T')[0]}.xlsx`);
    toast.success('Excel file downloaded successfully');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Admin Dashboard</h1>
            <p className="text-gray-600">Manage tests and view student results</p>
          </div>
          <Button variant="outline" onClick={handleLogout}>
            <LogOut className="mr-2 size-4" />
            Logout
          </Button>
        </div>

        <Tabs defaultValue="results" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="results">View Results</TabsTrigger>
            <TabsTrigger value="create">Create Test</TabsTrigger>
          </TabsList>

          <TabsContent value="results" className="space-y-6">
            {/* Statistics Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-lg font-medium">
                    Total Students
                  </CardTitle>
                  <Users className="size-8 opacity-75" />
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold">{totalStudents}</div>
                  <p className="text-xs text-blue-100 mt-1">
                    Students completed the test
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-amber-500 to-amber-600 text-white">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-lg font-medium">
                    Top Score
                  </CardTitle>
                  <Trophy className="size-8 opacity-75" />
                </CardHeader>
                <CardContent>
                  <div className="text-4xl font-bold">
                    {results.length > 0 ? `${results[0]?.percentage}%` : '-'}
                  </div>
                  <p className="text-xs text-amber-100 mt-1">
                    {results.length > 0 ? `${results[0]?.firstName} ${results[0]?.lastName}` : 'No results yet'}
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Results Filter */}
            <Card>
              <CardHeader>
                <CardTitle>Student Results</CardTitle>
                <CardDescription>
                  View and export test results for a specific month
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-4 items-end">
                  <div className="flex-1">
                    <Label htmlFor="month">Month</Label>
                    <Input
                      id="month"
                      placeholder="e.g., February2026"
                      value={selectedMonth}
                      onChange={(e) => setSelectedMonth(e.target.value)}
                    />
                  </div>
                  <Button onClick={fetchResults} disabled={loading}>
                    {loading ? 'Loading...' : 'Load Results'}
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={exportToExcel}
                    disabled={results.length === 0}
                  >
                    <Download className="mr-2 size-4" />
                    Export to Excel
                  </Button>
                </div>

                {/* Results Table */}
                {results.length > 0 && (
                  <div className="border rounded-lg overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-16">Rank</TableHead>
                          <TableHead>First Name</TableHead>
                          <TableHead>Last Name</TableHead>
                          <TableHead>Grade</TableHead>
                          <TableHead>Score</TableHead>
                          <TableHead>Percentage</TableHead>
                          <TableHead>Time Spent</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {results.map((result) => (
                          <TableRow key={`${result.firstName}_${result.lastName}_${result.grade}`}>
                            <TableCell className="font-bold">
                              {result.rank === 1 && '🥇'}
                              {result.rank === 2 && '🥈'}
                              {result.rank === 3 && '🥉'}
                              {result.rank > 3 && result.rank}
                            </TableCell>
                            <TableCell>{result.firstName}</TableCell>
                            <TableCell>{result.lastName}</TableCell>
                            <TableCell>{result.grade}</TableCell>
                            <TableCell>{result.score}/{result.totalQuestions}</TableCell>
                            <TableCell>
                              <span className={`font-semibold ${
                                parseFloat(result.percentage) >= 80 ? 'text-green-600' :
                                parseFloat(result.percentage) >= 60 ? 'text-yellow-600' :
                                'text-red-600'
                              }`}>
                                {result.percentage}%
                              </span>
                            </TableCell>
                            <TableCell>{Math.floor(result.timeSpent / 60)} min</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}

                {results.length === 0 && selectedMonth && !loading && (
                  <div className="text-center py-8 text-gray-500">
                    No results found for this month
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="create">
            <Card>
              <CardHeader>
                <CardTitle>Create New Test</CardTitle>
                <CardDescription>
                  Create a new test for students to take
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button 
                  onClick={() => navigate('/admin/create-test')}
                  size="lg"
                  className="w-full"
                >
                  <Plus className="mr-2 size-5" />
                  Create New Test
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
